#include "LinkedList.h"

class MyLinkedList: public LinkedList
{
    public:
        void insertAtTail(int value);
        void insertAtHead(int value);
        void printList();
};

void MyLinkedList::insertAtHead(int value)
{
    struct Node *node = new struct Node;
    node->data = value;
    node->next = nullptr;
    if (this->head == nullptr && this->tail == nullptr)
        this->head = this->tail = node;
    else
    {
        node->next = this->head;
        this->head = node;
    }
}

void MyLinkedList::insertAtTail(int value)
{
    struct Node *node = new struct Node;
    node->data = value;
    node->next = nullptr;
    if (this->head == nullptr && this->tail == nullptr) // empty linked list
        this->head = this->tail = node;
    else
    {
        this->tail->next = node;
        this->tail = node;
    }
}

void MyLinkedList::printList()
{
    struct Node *temp = this->head;
    if(this->head == nullptr && this->tail == nullptr)
    {
        cout<<"Empty linked list has no values to print!"<<endl;
        return ;
    }
    while (temp != nullptr)
    {
        cout<<temp->data<<endl;
        temp = temp->next;
        // printList();
    }
}
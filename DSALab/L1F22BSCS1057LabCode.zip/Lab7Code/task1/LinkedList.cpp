#include "LinkedList.h"

template <class T>
LinkedList<T>::LinkedList()
{
    this->head = this->tail = nullptr;
}
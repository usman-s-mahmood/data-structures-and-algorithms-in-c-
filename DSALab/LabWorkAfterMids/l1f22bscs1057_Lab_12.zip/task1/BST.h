#include "Tree.h"

template <class T>
class BST: public Tree<T>
{
    protected:
        void preorder(struct Node<T> *root);
        void inorder(struct Node<T> *root);
        void postorder(struct Node<T> *root);
    public:
        BST(): Tree<T>::Tree() {}
        void insert_node(T);
        void print_pre_order();
        void print_in_order();
        void print_post_order();
        bool isEmpty();
        ~BST(){}
};

template <class T>
bool BST<T>::isEmpty()
{
    return (this->root == NULL);
}

template <class T>
void BST<T>::insert_node(T value)
{
    struct Node<T> *node = new struct Node<T>;
    node->data = value;
    node->left = NULL;
    node->right = NULL;
    if (isEmpty())
        this->root = node;
    else
    {
        struct Node<T> *temp = this->root;
        while (true)
        {
            if (value < temp->data)
            {
                if (temp->left == NULL)
                {
                    temp->left = node;
                    break;
                }
                temp = temp->left;
            }
            else
            {
                if (temp->right == NULL)
                {
                    temp->right = node;
                    break;
                }
                temp = temp->right;
            }
        }
    }
}

template <class T>
void BST<T>::preorder(struct Node<T> *root)
{
    if (root != NULL)
    {
        cout << root->data << ' ';
        preorder(root->left);
        preorder(root->right);
    }
}

template <class T>
void BST<T>::inorder(struct Node<T> *root)
{
    if (root != NULL)
    {
        inorder(root->left);
        cout << root->data << ' ';
        inorder(root->right);
    }
}

template <class T>
void BST<T>::postorder(struct Node<T> *root)
{
    if (root != NULL)
    {
        postorder(root->left);
        postorder(root->right);
        cout << root->data << ' ';
    }
}

template <class T>
void BST<T>::print_in_order()
{
    if (!isEmpty())
    {
        inorder(this->root);
        cout << endl;
        return ;
    }
    cout << "Invalid Operation!" << endl;
}

template <class T>
void BST<T>::print_pre_order()
{
    if (!isEmpty())
    {
        preorder(this->root);
        cout << endl;
        return ;
    }
    cout << "Invalid Operation!" << endl;
}

template <class T>
void BST<T>::print_post_order()
{
    if (!isEmpty())
    {
        postorder(this->root);
        cout << endl;
        return ;
    }
    cout << "Invalid Operation!" << endl;
}

#include "BST.h"

int main()
{
    BST<int> obj;
    int ch = -1;
    while (ch != 5)
    {
        cout << "Binary Tree system!" << endl
            << "1. To insert a node" << endl
            << "2. For in order traversal" << endl
            << "3. For post order traversal" << endl
            << "4. For pre order traversal" << endl
            << "5. To Exit" << endl
            << "Enter Your Choice: ";
        cin >> ch;
        if (ch == 1)
        {
            cout << "Enter a value: ";
            int value;
            cin >> value;
            obj.insert_node(value);
            cout << "Press any key to continue!" << endl;
            getch();
        }
        else if (ch == 2)
        {
            obj.print_in_order();
            cout << "Press any key to continue!" << endl;
            getch();
        }
        else if (ch == 3)
        {
            obj.print_post_order();
            cout << "Press any key to continue!" << endl;
            getch();
        }
        else if (ch == 4)
        {
            obj.print_pre_order();
            cout << "Press any key to continue!" << endl;
            getch();
        }
        else if (ch == 5)
        {
            cout << "Program terminated!" << endl;
            break;
        }
        else
        {
            cout << "Invalid Option! Program terminated" << endl;
            break;
        }
    }
    return 0;
}
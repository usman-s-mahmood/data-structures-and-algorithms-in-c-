#include "Tree.h"


template <class T>
class BST: public Tree<T>
{
    protected:
        void preorder(struct Node<T> *root);
        void inorder(struct Node<T> *root);
        void postorder(struct Node<T> *root);
        struct Node<T>* deleteNode(struct Node<T>* root, T key);
        struct Node<T>* minValueNode(struct Node<T>* node) ;
    public:
        BST(): Tree<T>::Tree() {}
        void insert_node(T);
        void print_pre_order();
        void print_in_order();
        void print_post_order();
        void delete_node(T value);
        T find_min();
        T find_max();
        bool isEmpty();
        ~BST(){}
};

template <class T>
bool BST<T>::isEmpty()
{
    return (this->root == NULL);
}

template <class T>
void BST<T>::insert_node(T value)
{
    struct Node<T> *node = new struct Node<T>;
    node->data = value;
    node->left = NULL;
    node->right = NULL;
    if (isEmpty())
        this->root = node;
    else
    {
        struct Node<T> *temp = this->root;
        while (true)
        {
            if (value < temp->data)
            {
                if (temp->left == NULL)
                {
                    temp->left = node;
                    break;
                }
                temp = temp->left;
            }
            else
            {
                if (temp->right == NULL)
                {
                    temp->right = node;
                    break;
                }
                temp = temp->right;
            }
        }
    }
}

template <class T>
void BST<T>::preorder(struct Node<T> *root)
{
    if (root != NULL)
    {
        cout << root->data << ' ';
        preorder(root->left);
        preorder(root->right);
    }
}

template <class T>
void BST<T>::inorder(struct Node<T> *root)
{
    if (root != NULL)
    {
        inorder(root->left);
        cout << root->data << ' ';
        inorder(root->right);
    }
}

template <class T>
void BST<T>::postorder(struct Node<T> *root)
{
    if (root != NULL)
    {
        postorder(root->left);
        postorder(root->right);
        cout << root->data << ' ';
    }
}

template <class T>
void BST<T>::print_in_order()
{
    if (!isEmpty())
    {
        inorder(this->root);
        cout << endl;
        return ;
    }
    cout << "Invalid Operation!" << endl;
}

template <class T>
void BST<T>::print_pre_order()
{
    if (!isEmpty())
    {
        preorder(this->root);
        cout << endl;
        return ;
    }
    cout << "Invalid Operation!" << endl;
}

template <class T>
void BST<T>::print_post_order()
{
    if (!isEmpty())
    {
        postorder(this->root);
        cout << endl;
        return ;
    }
    cout << "Invalid Operation!" << endl;
}

template <class T>
void BST<T>::delete_node(T value)
{
    this->root = deleteNode(this->root, value);
}

template <class T>
struct Node<T>* BST<T>::deleteNode(struct Node<T>* root, T key) 
{
    if (root == NULL) 
        return root;

    if (key < root->data)
        root->left = deleteNode(root->left, key);
    else if (key > root->data)
        root->right = deleteNode(root->right, key);
    else 
    {
        if (root->left == NULL) 
        {
            struct Node<T>* temp = root->right;
            delete root;
            return temp;
        } 
        else if (root->right == NULL) 
        {
            struct Node<T>* temp = root->left;
            delete root;
            return temp;
        }

        struct Node<T>* temp = minValueNode(root->right);
        root->data = temp->data;
        root->right = deleteNode(root->right, temp->data);
    }
    return root;
}

template <class T>
struct Node<T>* BST<T>::minValueNode(struct Node<T>* node) 
{
    struct Node<T>* current = node;
    while (current && current->left != NULL)
        current = current->left;
    return current;
}

template <class T>
T BST<T>::find_min()
{
    if (this->isEmpty()) 
    {
        cerr << "Tree is empty!" << endl;
        return T();
    }
    struct Node<T>* temp = this->root;
    while (temp->left != NULL)
        temp = temp->left;
    return temp->data;
}

template <class T>
T BST<T>::find_max()
{
    if (this->isEmpty()) 
    {
        cerr << "Tree is empty!" << endl;
        return T();
    }
    struct Node<T>* temp = this->root;
    while (temp->right != NULL)
        temp = temp->right;
    return temp->data;
}

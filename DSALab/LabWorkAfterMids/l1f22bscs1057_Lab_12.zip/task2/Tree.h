#include <iostream>
#include <string>
#include <cmath>
#include <stdlib.h>
#include <conio.h>

using namespace std;

template <class T>
struct Node
{
    T data;
    struct Node<T> *left;
    struct Node<T> *right;
};

template <class T>
class Tree
{
    protected:
        struct Node<T> *root;
    public:
        Tree();
        virtual void insert_node(T) = 0;
        virtual void print_pre_order() = 0;
        virtual void print_in_order() = 0;
        virtual void print_post_order() = 0;
        ~Tree(){}
};

template <class T>
Tree<T>::Tree()
{
    this->root = NULL;
}
